# =============================================================================
# Data-Driven Nutritional Analysis & Visualization Framework
# =============================================================================
# Dataset : nutrients_data.csv (335 food items, 10 columns)
# Models  : Logistic Regression | SVM | Random Forest | XGBoost (optional)
# Target  : calorie_group  →  Low (<100) | Medium (100–300) | High (>300)
# =============================================================================

import os
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")           # non-interactive backend for file output
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.preprocessing   import StandardScaler, LabelEncoder
from sklearn.linear_model    import LogisticRegression
from sklearn.svm             import SVC
from sklearn.ensemble        import RandomForestClassifier
from sklearn.metrics         import (accuracy_score, precision_score,
                                     recall_score, f1_score,
                                     roc_auc_score, confusion_matrix,
                                     ConfusionMatrixDisplay,
                                     classification_report)

# XGBoost is optional – import gracefully
try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

warnings.filterwarnings("ignore")

# ── Output directory ──────────────────────────────────────────────────────────
OUTPUT_DIR = "/mnt/user-data/outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── Plotting style ────────────────────────────────────────────────────────────
plt.rcParams.update({
    "figure.dpi": 130,
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 9,
})
PALETTE = "Set2"


# =============================================================================
# 1. DATA LOADING & CLEANING
# =============================================================================

def load_and_clean(path: str) -> pd.DataFrame:
    """
    Load the CSV, handle 'trace' values (represented as 't'),
    strip commas from numbers, convert to float, and impute
    missing values with column medians.
    """
    df = pd.read_csv(path)
    print(f"[INFO] Loaded  →  {df.shape[0]} rows × {df.shape[1]} cols")
    print(f"[INFO] Columns : {df.columns.tolist()}")

    # ── Numeric columns we care about ─────────────────────────────────────
    numeric_cols = ["Grams", "Calories", "Protein", "Fat", "Fiber", "Carbs"]

    for col in numeric_cols:
        if col not in df.columns:
            continue
        # Cast to string so we can apply string operations uniformly
        series = df[col].astype(str)
        # 't' means trace amounts (< 0.5) → treat as 0
        series = series.replace(r"^t$", "0", regex=True)
        # Remove commas used as thousands separators  (e.g. "1,419" → "1419")
        series = series.str.replace(",", "", regex=False)
        # Remove any remaining non-numeric characters except dot / minus
        series = series.str.replace(r"[^\d.\-]", "", regex=True)
        # Coerce to numeric; un-parseable → NaN
        df[col] = pd.to_numeric(series, errors="coerce")

    # ── Impute missing numerics with column median ─────────────────────────
    missing_before = df[numeric_cols].isnull().sum().sum()
    for col in numeric_cols:
        if df[col].isnull().any():
            median_val = df[col].median()
            df[col].fillna(median_val, inplace=True)
            print(f"[INFO] Imputed  '{col}'  with median={median_val:.2f}")

    print(f"[INFO] Missing values fixed  →  {missing_before} → 0")
    return df


# =============================================================================
# 2. OUTLIER DETECTION & HANDLING (IQR method)
# =============================================================================

def handle_outliers(df: pd.DataFrame, cols: list, factor: float = 3.0) -> pd.DataFrame:
    """
    Clip extreme outliers beyond `factor` × IQR.
    A wide factor (3×) preserves legitimate nutritional extremes
    while removing data entry errors.
    """
    for col in cols:
        q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
        iqr = q3 - q1
        lo, hi = q1 - factor * iqr, q3 + factor * iqr
        n_out = ((df[col] < lo) | (df[col] > hi)).sum()
        if n_out:
            df[col] = df[col].clip(lower=lo, upper=hi)
            print(f"[INFO] Outliers clipped  '{col}'  →  {n_out} values  "
                  f"(range [{lo:.1f}, {hi:.1f}])")
    return df


# =============================================================================
# 3. FEATURE ENGINEERING
# =============================================================================

def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Derive new nutritional features from raw columns.
    """
    eps = 1e-6   # avoid division by zero

    # Nutrient density  (higher → more nutritious per calorie)
    df["nutrient_density"] = (df["Protein"] + df["Fiber"]) / (df["Calories"] + eps)

    # Macronutrient ratios  (fraction of total macro-grams)
    total_macros = df["Protein"] + df["Fat"] + df["Carbs"] + eps
    df["protein_ratio"] = df["Protein"] / total_macros
    df["fat_ratio"]     = df["Fat"]     / total_macros
    df["carb_ratio"]    = df["Carbs"]   / total_macros

    # Calories per gram  (energy density)
    if "Grams" in df.columns:
        df["calories_per_gram"] = df["Calories"] / (df["Grams"] + eps)

    # ── Target variable ────────────────────────────────────────────────────
    def calorie_group(cal):
        if cal < 100:
            return "Low"
        elif cal <= 300:
            return "Medium"
        else:
            return "High"

    df["calorie_group"] = df["Calories"].apply(calorie_group)

    print("\n[INFO] calorie_group distribution:")
    print(df["calorie_group"].value_counts().to_string())
    return df


# =============================================================================
# 4. EXPLORATORY DATA ANALYSIS (EDA)
# =============================================================================

def plot_eda(df: pd.DataFrame):
    """Produce and save all EDA figures."""

    num_features = ["Calories", "Protein", "Fat", "Carbs", "Fiber",
                     "nutrient_density", "protein_ratio", "fat_ratio", "carb_ratio"]

    # ── 4a. Histograms ────────────────────────────────────────────────────
    fig, axes = plt.subplots(3, 3, figsize=(15, 11))
    fig.suptitle("Feature Distributions", fontsize=15, fontweight="bold", y=1.01)
    for ax, col in zip(axes.flat, num_features):
        ax.hist(df[col].dropna(), bins=30, color="#4C72B0", edgecolor="white", alpha=0.85)
        ax.set_title(col)
        ax.set_xlabel("Value")
        ax.set_ylabel("Count")
    plt.tight_layout()
    fig.savefig(f"{OUTPUT_DIR}/eda_histograms.png", bbox_inches="tight")
    plt.close(fig)
    print("[SAVED] eda_histograms.png")

    # ── 4b. Correlation heat-map ──────────────────────────────────────────
    corr_cols = ["Calories", "Protein", "Fat", "Carbs", "Fiber",
                 "nutrient_density", "calories_per_gram",
                 "protein_ratio", "fat_ratio", "carb_ratio"]
    corr_cols = [c for c in corr_cols if c in df.columns]
    corr = df[corr_cols].corr()

    fig, ax = plt.subplots(figsize=(11, 9))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm",
                linewidths=0.5, square=True, ax=ax,
                annot_kws={"size": 8})
    ax.set_title("Correlation Heat-map", fontsize=14, fontweight="bold")
    plt.tight_layout()
    fig.savefig(f"{OUTPUT_DIR}/eda_correlation_heatmap.png", bbox_inches="tight")
    plt.close(fig)
    print("[SAVED] eda_correlation_heatmap.png")

    # ── 4c. Scatter plots ─────────────────────────────────────────────────
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))

    group_colors = {"Low": "#2ecc71", "Medium": "#f39c12", "High": "#e74c3c"}
    for grp, grp_df in df.groupby("calorie_group"):
        ax1.scatter(grp_df["Calories"], grp_df["Protein"],
                    label=grp, color=group_colors[grp], alpha=0.65, s=40, edgecolors="none")
    ax1.set_xlabel("Calories")
    ax1.set_ylabel("Protein (g)")
    ax1.set_title("Protein vs Calories")
    ax1.legend(title="Calorie Group")

    for grp, grp_df in df.groupby("calorie_group"):
        ax2.scatter(grp_df["Carbs"], grp_df["Fat"],
                    label=grp, color=group_colors[grp], alpha=0.65, s=40, edgecolors="none")
    ax2.set_xlabel("Carbs (g)")
    ax2.set_ylabel("Fat (g)")
    ax2.set_title("Fat vs Carbs")
    ax2.legend(title="Calorie Group")

    plt.suptitle("Scatter Plots – Macronutrient Relationships", fontweight="bold")
    plt.tight_layout()
    fig.savefig(f"{OUTPUT_DIR}/eda_scatter_plots.png", bbox_inches="tight")
    plt.close(fig)
    print("[SAVED] eda_scatter_plots.png")

    # ── 4d. Box-plots (outlier inspection) ───────────────────────────────
    box_cols = ["Calories", "Protein", "Fat", "Carbs", "Fiber"]
    fig, axes = plt.subplots(1, len(box_cols), figsize=(16, 5))
    for ax, col in zip(axes, box_cols):
        ax.boxplot(df[col].dropna(), patch_artist=True,
                   boxprops=dict(facecolor="#AED6F1", color="#1B4F72"),
                   medianprops=dict(color="#E74C3C", linewidth=2))
        ax.set_title(col)
        ax.set_xlabel("")
        ax.set_ylabel("Value")
    plt.suptitle("Box-plots – Outlier Inspection", fontweight="bold")
    plt.tight_layout()
    fig.savefig(f"{OUTPUT_DIR}/eda_boxplots.png", bbox_inches="tight")
    plt.close(fig)
    print("[SAVED] eda_boxplots.png")


# =============================================================================
# 5. MODEL TRAINING & EVALUATION
# =============================================================================

FEATURE_COLS = [
    "Calories", "Protein", "Fat", "Carbs", "Fiber",
    "nutrient_density", "protein_ratio", "fat_ratio", "carb_ratio",
    "calories_per_gram"
]


def prepare_data(df: pd.DataFrame):
    """Split features / labels and apply train-test split with stratification."""
    feat_cols = [c for c in FEATURE_COLS if c in df.columns]
    X = df[feat_cols].copy()
    y = df["calorie_group"].copy()

    # Encode labels  →  0=High, 1=Low, 2=Medium  (alphabetical)
    le = LabelEncoder()
    y_enc = le.fit_transform(y)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y_enc, test_size=0.25, random_state=42, stratify=y_enc
    )
    print(f"\n[INFO] Train size: {len(X_train)}  |  Test size: {len(X_test)}")

    # Scale features for distance/gradient-based models
    scaler = StandardScaler()
    X_train_sc = scaler.fit_transform(X_train)
    X_test_sc  = scaler.transform(X_test)

    return (X_train, X_test, X_train_sc, X_test_sc,
            y_train, y_test, le, feat_cols, scaler)


def evaluate_model(model, X_test, y_test, le):
    """Return a dict of evaluation metrics for one model."""
    y_pred = model.predict(X_test)
    metrics = {
        "Accuracy"  : accuracy_score(y_test, y_pred),
        "Precision" : precision_score(y_test, y_pred, average="macro", zero_division=0),
        "Recall"    : recall_score   (y_test, y_pred, average="macro", zero_division=0),
        "F1-Score"  : f1_score       (y_test, y_pred, average="macro", zero_division=0),
    }
    # ROC-AUC (one-vs-rest, requires probability estimates)
    if hasattr(model, "predict_proba"):
        y_prob = model.predict_proba(X_test)
        try:
            metrics["ROC-AUC"] = roc_auc_score(
                y_test, y_prob, multi_class="ovr", average="macro"
            )
        except ValueError:
            metrics["ROC-AUC"] = np.nan
    else:
        metrics["ROC-AUC"] = np.nan
    return metrics


def train_all_models(X_train, X_test, X_train_sc, X_test_sc, y_train, y_test, le):
    """
    Train Logistic Regression, SVM, Random Forest (and XGBoost if available).
    Scaled data is used for LR and SVM; raw data for tree-based models.
    Returns results dict and the trained model objects.
    """
    n_classes = len(np.unique(y_train))

    models = {
        "Logistic Regression": (
            LogisticRegression(max_iter=1000, random_state=42,
                               class_weight="balanced"),
            X_train_sc, X_test_sc
        ),
        "SVM": (
            SVC(kernel="rbf", probability=True, random_state=42,
                class_weight="balanced"),
            X_train_sc, X_test_sc
        ),
        "Random Forest": (
            RandomForestClassifier(n_estimators=200, max_depth=None,
                                   random_state=42, class_weight="balanced",
                                   n_jobs=-1),
            X_train, X_test
        ),
    }

    if XGBOOST_AVAILABLE:
        models["XGBoost"] = (
            XGBClassifier(n_estimators=200, learning_rate=0.1,
                          use_label_encoder=False,
                          eval_metric="mlogloss", random_state=42),
            X_train, X_test
        )

    results   = {}
    trained   = {}

    for name, (model, X_tr, X_te) in models.items():
        print(f"\n[TRAIN] {name} …")
        model.fit(X_tr, y_train)
        metrics = evaluate_model(model, X_te, y_test, le)
        results[name] = metrics
        trained[name] = (model, X_tr, X_te)

        print(f"        Accuracy  = {metrics['Accuracy']:.4f}")
        print(f"        F1-Score  = {metrics['F1-Score']:.4f}")
        print(f"        ROC-AUC   = {metrics['ROC-AUC']:.4f}" if not np.isnan(metrics["ROC-AUC"]) else "        ROC-AUC   = N/A")

    return results, trained


# =============================================================================
# 6. MODEL COMPARISON
# =============================================================================

def compare_models(results: dict) -> str:
    """Print a comparison table and return the name of the best model."""
    df_res = pd.DataFrame(results).T
    df_res = df_res[["Accuracy", "Precision", "Recall", "F1-Score", "ROC-AUC"]]
    df_res = df_res.round(4)

    print("\n" + "="*65)
    print("MODEL COMPARISON")
    print("="*65)
    print(df_res.to_string())
    print("="*65)

    best = df_res["F1-Score"].idxmax()
    print(f"\n★  Best model by F1-Score  →  {best}  "
          f"(F1 = {df_res.loc[best,'F1-Score']:.4f})\n")
    return best, df_res


# =============================================================================
# 7. FINAL VISUALIZATIONS
# =============================================================================

def plot_model_comparison(df_results: pd.DataFrame):
    """Bar chart comparing all models across metrics."""
    metrics = ["Accuracy", "Precision", "Recall", "F1-Score"]
    x = np.arange(len(metrics))
    width = 0.18
    colors = ["#3498DB", "#E74C3C", "#2ECC71", "#9B59B6", "#F39C12"]

    fig, ax = plt.subplots(figsize=(13, 6))
    for i, (model_name, row) in enumerate(df_results.iterrows()):
        vals = [row[m] for m in metrics]
        offset = (i - len(df_results) / 2 + 0.5) * width
        bars = ax.bar(x + offset, vals, width, label=model_name,
                      color=colors[i % len(colors)], edgecolor="white", alpha=0.9)
        for bar in bars:
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width() / 2, h + 0.005,
                    f"{h:.2f}", ha="center", va="bottom", fontsize=7.5)

    ax.set_xticks(x)
    ax.set_xticklabels(metrics, fontsize=11)
    ax.set_ylim(0, 1.12)
    ax.set_ylabel("Score")
    ax.set_title("Model Comparison – Classification Metrics", fontsize=14, fontweight="bold")
    ax.legend(loc="upper right")
    ax.axhline(1.0, linestyle="--", color="grey", linewidth=0.8, alpha=0.6)
    plt.tight_layout()
    fig.savefig(f"{OUTPUT_DIR}/model_comparison.png", bbox_inches="tight")
    plt.close(fig)
    print("[SAVED] model_comparison.png")


def plot_confusion_matrix(model, X_test, y_test, le, model_name: str):
    """Confusion matrix for the best model."""
    y_pred = model.predict(X_test)
    cm     = confusion_matrix(y_test, y_pred)
    labels = le.classes_

    fig, ax = plt.subplots(figsize=(7, 6))
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
    disp.plot(ax=ax, cmap="Blues", colorbar=False)
    ax.set_title(f"Confusion Matrix – {model_name}", fontsize=13, fontweight="bold")
    plt.tight_layout()
    fig.savefig(f"{OUTPUT_DIR}/confusion_matrix_best.png", bbox_inches="tight")
    plt.close(fig)
    print("[SAVED] confusion_matrix_best.png")

    print(f"\nClassification Report – {model_name}:")
    print(classification_report(y_test, y_pred, target_names=labels))


def plot_feature_importance(rf_model, feat_cols: list):
    """Horizontal bar chart of Random Forest feature importances."""
    importances = pd.Series(rf_model.feature_importances_, index=feat_cols)
    importances = importances.sort_values(ascending=True)

    fig, ax = plt.subplots(figsize=(9, 6))
    bars = ax.barh(importances.index, importances.values,
                   color=plt.cm.viridis(np.linspace(0.2, 0.85, len(importances))),
                   edgecolor="white", height=0.6)
    for bar, val in zip(bars, importances.values):
        ax.text(val + 0.002, bar.get_y() + bar.get_height() / 2,
                f"{val:.3f}", va="center", fontsize=8.5)
    ax.set_xlabel("Importance (Gini)")
    ax.set_title("Random Forest – Feature Importance", fontsize=13, fontweight="bold")
    ax.set_xlim(0, importances.max() * 1.18)
    plt.tight_layout()
    fig.savefig(f"{OUTPUT_DIR}/feature_importance.png", bbox_inches="tight")
    plt.close(fig)
    print("[SAVED] feature_importance.png")


# =============================================================================
# 8. PREDICTION FUNCTION
# =============================================================================

def predict_calorie_group(model, scaler, le, feat_cols: list,
                           needs_scaling: bool = True, **food_values):
    """
    Predict the calorie group for a new food item.

    Parameters
    ----------
    model         : trained classifier
    scaler        : fitted StandardScaler (pass None if model doesn't need it)
    le            : fitted LabelEncoder
    feat_cols     : list of feature names the model was trained on
    needs_scaling : whether to apply the scaler before prediction
    **food_values : keyword arguments for each feature, e.g. Calories=200, Protein=10, …

    Returns
    -------
    str : "Low" | "Medium" | "High"

    Example
    -------
    predict_calorie_group(model, scaler, le, feat_cols,
                          Calories=250, Protein=15, Fat=8,
                          Carbs=30, Fiber=2, Grams=100)
    """
    # Build input row using defaults of 0 for any missing feature
    row = {col: 0.0 for col in feat_cols}
    row.update(food_values)

    # Re-derive engineered features from the supplied raw values
    eps = 1e-6
    cal     = row.get("Calories", 0)
    protein = row.get("Protein",  0)
    fat     = row.get("Fat",      0)
    carbs   = row.get("Carbs",    0)
    fiber   = row.get("Fiber",    0)
    grams   = row.get("Grams",    100)

    row["nutrient_density"]  = (protein + fiber) / (cal + eps)
    total = protein + fat + carbs + eps
    row["protein_ratio"]     = protein / total
    row["fat_ratio"]         = fat     / total
    row["carb_ratio"]        = carbs   / total
    row["calories_per_gram"] = cal     / (grams + eps)

    X_new = np.array([[row[c] for c in feat_cols]])
    if needs_scaling and scaler is not None:
        X_new = scaler.transform(X_new)

    pred_enc   = model.predict(X_new)[0]
    pred_label = le.inverse_transform([pred_enc])[0]
    return pred_label


# =============================================================================
# 9. SIMPLE CLI  (bonus)
# =============================================================================

def cli_predict(model, scaler, le, feat_cols, needs_scaling=True):
    """Interactive command-line prediction loop."""
    print("\n" + "="*55)
    print("  Nutritional Calorie Group Predictor  (type 'q' to quit)")
    print("="*55)
    while True:
        try:
            raw = input("\nEnter Calories, Protein(g), Fat(g), Carbs(g), Fiber(g), Grams"
                        "\n  (comma-separated, e.g. 250,15,8,30,2,100) : ").strip()
            if raw.lower() in ("q", "quit", "exit"):
                print("Goodbye!")
                break
            parts = [float(x) for x in raw.split(",")]
            keys  = ["Calories", "Protein", "Fat", "Carbs", "Fiber", "Grams"]
            vals  = dict(zip(keys, parts))
            group = predict_calorie_group(model, scaler, le, feat_cols,
                                          needs_scaling=needs_scaling, **vals)
            print(f"\n  ▶  Predicted Calorie Group : {group}")
        except (ValueError, KeyboardInterrupt):
            print("Invalid input or interrupted. Try again or type 'q'.")


# =============================================================================
# MAIN
# =============================================================================

def main():
    print("\n" + "="*65)
    print("  Nutritional Analysis & ML Framework")
    print("="*65 + "\n")

    # ── 1. Load & clean ───────────────────────────────────────────────────
    DATA_PATH = "/mnt/user-data/uploads/nutrients_data.csv"
    df = load_and_clean(DATA_PATH)

    # ── 2. Outlier handling ───────────────────────────────────────────────
    outlier_cols = ["Calories", "Protein", "Fat", "Carbs", "Fiber", "Grams"]
    df = handle_outliers(df, outlier_cols, factor=3.0)

    # ── 3. Feature engineering ────────────────────────────────────────────
    df = engineer_features(df)

    # Safety net: replace any residual NaN / Inf in feature cols with 0
    feat_cols_all = [c for c in FEATURE_COLS if c in df.columns]
    df[feat_cols_all] = (
        df[feat_cols_all]
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0)
    )

    # ── 4. EDA ────────────────────────────────────────────────────────────
    print("\n[EDA] Generating plots …")
    plot_eda(df)

    # ── 5. Prepare data ───────────────────────────────────────────────────
    (X_train, X_test,
     X_train_sc, X_test_sc,
     y_train, y_test,
     le, feat_cols, scaler) = prepare_data(df)

    # ── 6. Train & evaluate models ────────────────────────────────────────
    results, trained = train_all_models(
        X_train, X_test, X_train_sc, X_test_sc, y_train, y_test, le
    )

    # ── 7. Compare models ────────────────────────────────────────────────
    best_name, df_results = compare_models(results)

    # ── 8. Visualise results ─────────────────────────────────────────────
    plot_model_comparison(df_results)

    best_model, best_X_tr, best_X_te = trained[best_name]
    plot_confusion_matrix(best_model, best_X_te, y_test, le, best_name)

    # Feature importance (always from Random Forest)
    if "Random Forest" in trained:
        rf_model, _, _ = trained["Random Forest"]
        plot_feature_importance(rf_model, feat_cols)

    # ── 9. Demo prediction ───────────────────────────────────────────────
    print("\n[DEMO] Prediction examples:")
    demo_foods = [
        {"name": "Apple",          "Calories": 95,  "Protein": 0.5, "Fat": 0.3, "Carbs": 25, "Fiber": 4.4, "Grams": 182},
        {"name": "Chicken Breast", "Calories": 165, "Protein": 31,  "Fat": 3.6, "Carbs": 0,  "Fiber": 0,   "Grams": 100},
        {"name": "Butter",         "Calories": 717, "Protein": 0.9, "Fat": 81,  "Carbs": 0,  "Fiber": 0,   "Grams": 100},
    ]
    # For the best model determine whether scaling is needed
    needs_sc = best_name in ("Logistic Regression", "SVM")
    sc_to_use = scaler if needs_sc else None

    for food in demo_foods:
        name = food.pop("name")
        group = predict_calorie_group(best_model, sc_to_use, le, feat_cols,
                                       needs_scaling=needs_sc, **food)
        print(f"  {name:<20}  →  {group}")

    print("\n[DONE] All outputs saved to:", OUTPUT_DIR)

    # ── 10. (Optional) CLI mode ───────────────────────────────────────────
    # Uncomment the next two lines to enable interactive predictions:
    # print("\nStarting interactive CLI …")
    # cli_predict(best_model, sc_to_use, le, feat_cols, needs_scaling=needs_sc)


if __name__ == "__main__":
    main()
